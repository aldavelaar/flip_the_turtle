"""
This program uses Ken Lambert's breezypythongui.py version 1.0, copyright 2012 by Ken Lambert

"""

from breezypythongui import EasyFrame

class TextFieldDemo(EasyFrame):

    def __init__(self):
        EasyFrame.__init__(self)

        # Label and field for the input
        self.addLabel(text = "Description",
                      row = 0, column = 0)
        self.descField = self.addTextField(text = "",
                                            row = 0,
                                            column = 1)

        # Label and field for the output
        self.addLabel(text = "Date",
                      row = 1, column = 0)
        self.dateField = self.addTextField(text = "",
                                             row = 1,
                                             column = 1)

        # The command button
        self.button = self.addButton(text = "Add task",
                                     row = 2, column = 0,
                                     columnspan = 2,
                                     command = self.convert)

    # The event handling method for the button
    def convert(self):
        self.descField.setText('')
        self.dateField.setText('')

#Instantiate and pop up the window."""
if __name__ == "__main__":
    TextFieldDemo().mainloop()
