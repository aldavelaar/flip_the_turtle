# import module
import os
from tkinter import *
# this messagebox will become useful later
from tkinter import messagebox

# images
filePath = os.path.dirname(__file__)

# FUNCTIONS
# ---------

def createTask():
    description = descriptionEntry.get()
    date = dateEntry.get()
    if description == '':
        messagebox.showwarning('Error', 'Please enter a task first.')
    else:
        if date == '':
            task = f'{description} - no assigned date'
        else:
            task = f'{description} - {date}'
        lb.insert(END, task)

# this function erases the text in the text boxes
def clearEntries():
    descriptionEntry.delete(0, "end")
    dateEntry.delete(0, "end")

# this removes a task from the list of tasks
def completeTask():
    lb.delete(ANCHOR)

# this large fuction creates a second window which will be the 'help' page.
def getHelp():
    # This creates a second window which will be the 'help' page.
    help = Toplevel()
    # This sizes and positions the window
    help.geometry('700x1000+1700+300')
    # This assigns a visible title to the window
    help.title('Flip the Turtle - Help')
    # This sets the background color of the window
    help.config(bg = '#f4a460')
    # This prevents the user from resizing the window
    help.resizable(width = False, height = False)

    # label widget: HELP - this is the only label that will appear in the help window
    helpLabel = Label(help,
                  text = 'Flip the Turtle is a simple to-do list application where you can store your tasks, activities, and important ideas. You can create new tasks and view all of your activities at once, as well as check-off and delete completed tasks. To quit the program, click the turtle with shades. To add a task, enter the appropriate information into the text boxes, then click ADD TASK. When you add a task, you are required to enter a description. You are not required to enter a date if you choose not to. To erase the text inside both text boxes, click CLEAR ENTRIES. At the top of the window is the list of tasks. To remove or complete a task, click on that task, then click COMPLETE TASK. You can find my GitHub repository at https://github.com/aldavelaar/flip_the_turtle.',
                  font = ('Times 14', 15),
                  bg = '#f4a460',
                  wraplength = 450
    )
    helpLabel.pack(pady = 10)

    # button widget: HELP - this is the only button that will appear in the help window
    buttonFrameHelp = Frame(help)
    buttonFrameHelp.pack(pady = 40)

    # 'close window' button widget
    closeHelpBtn = Button(buttonFrameHelp,
                     text = 'Close',
                     font = ('Times 14', 20),
                     bg = '#ff8b61',
                     padx = 25,
                     pady = 15,
                     command = help.destroy,
    )
    closeHelpBtn.pack(fill = BOTH, expand = True, side = LEFT)

# MAIN WINDOW CREATION
# --------------------

# This creates the main window
ws = Tk()
# This sizes and positions the window
ws.geometry('700x1000+1000+300')
# This assigns a visible title to the window
ws.title('Flip the Turtle')
# This sets the background color of the window
ws.config(bg = '#f4a460')
# This prevents the user from resizing the window
ws.resizable(width = False, height = False)

# MAIN WINDOW WIDGET CREATION
# ---------------------------

# listbox widget
frame = Frame(ws)
frame.pack(pady = 20)

# this makes the list box
lb = Listbox(frame,
             width = 40,
             height = 8,
             font = ('Times 14', 20),
             bd = 5,
             bg = '#a6a6a6',
             fg = '#464646',
             highlightthickness = 0,
             selectbackground = '#000000',
             selectforeground = '#ffffff',
             activestyle = 'underline',
)
lb.pack(side = LEFT, fill = BOTH)

# list of tasks
tasks = []

# configures the listbox
for item in tasks:
    lb.insert(END, item)

# scrollbar for the listbox
sb = Scrollbar(frame)
sb.pack(side = RIGHT, fill = BOTH)
lb.config(yscrollcommand = sb.set)
sb.config(command = lb.yview)

# button widgets - I created a seperate space for these three buttons
buttonFrameTop = Frame(ws)
buttonFrameTop.pack(pady = 40)

# 'complete task' button widget
completeTaskBtn = Button(buttonFrameTop,
                         text = 'Complete Task',
                         font = ('Times 14', 20),
                         bg = '#ff8b61',
                         padx = 25,
                         pady = 15,
                         command = completeTask,
)
completeTaskBtn.pack(fill = BOTH, expand = True, side = LEFT)

# 'help' button widget
getHelpBtn = Button(buttonFrameTop,
                         text = 'Help',
                         font = ('Times 14', 20),
                         bg = '#ff8b61',
                         padx = 25,
                         pady = 15,
                         command = getHelp,
)
getHelpBtn.pack(fill = BOTH, expand = True, side = LEFT)

# 'quit program' button widget
shades = PhotoImage(file = os.path.join(filePath, "images/shades.png"))
shades = shades.subsample(2, 2)
quitBtn = Button(buttonFrameTop,
                         text = 'Quit',
                         image = shades,
                         font = ('Times 14', 20),
                         bg = '#ff8b61',
                         padx = 25,
                         pady = 15,
                         command = ws.quit,
)
quitBtn.pack(fill = BOTH, expand = True, side = LEFT)

# label widget: DESCRIPTION
descriptionLabel = Label(ws,
              text = 'Task Description',
              font = ('Times 14', 15),
              bg = '#f4a460',
)
descriptionLabel.pack(pady = 10)

# entry box widget: DESCRIPTION
descriptionEntry = Entry(ws,
              font = ('Times 14', 20),
)
descriptionEntry.pack(pady = 5)

# label widget: DATE
dateLabel = Label(ws,
              text = 'Date of Task',
              font = ('Times 14', 15),
              bg = '#f4a460',
)
dateLabel.pack(pady = 10)

# entry box widget: DATE
dateEntry = Entry(ws,
              font = ('Times 14', 20),
)
dateEntry.pack(pady = 5)

# button widgets - I created a seperate space for these two buttons
buttonFrameBottom = Frame(ws)
buttonFrameBottom.pack(pady = 20)

# 'add task' button widget
createTaskBtn = Button(buttonFrameBottom,
                       text = 'Add Task',
                       font = ('Times 14', 20),
                       bg = '#c5f776',
                       padx = 25,
                       pady = 15,
                       command = createTask,
)
createTaskBtn.pack(fill = BOTH, expand = True, side = LEFT)

# 'clear entries' button widget
createTaskBtn = Button(buttonFrameBottom,
                       text = 'Clear Entries',
                       font = ('Times 14', 20),
                       bg = '#c5f776',
                       padx = 25,
                       pady = 15,
                       command = clearEntries,
)
createTaskBtn.pack(fill = BOTH, expand = True, side = LEFT)

# label widget: TURTLE
img = PhotoImage(file = os.path.join(filePath, "images/turtle.png"))
img = img.subsample(4, 4)
turtleLabel = Label(ws,
                         image = img,
                         text = 'Flip the Turtle',
                         font = ('Times 14', 15),
                         bg = '#f4a460',
)
turtleLabel.pack(pady = 10)

# this mainloop will run the program
ws.mainloop()

# program end